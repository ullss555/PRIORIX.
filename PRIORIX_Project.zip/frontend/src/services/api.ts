import axios, { AxiosError } from 'axios';
import {
  Ticket,
  TicketListResponse,
  Incident,
  Agent,
  AgentRecommendation,
  DashboardStats,
  TicketHistoryItem,
  TicketEventItem,
  AiCategorizeResult,
  AiAnalyzeResult,
  AiSuggestResponseResult,
  AiRelatedMatch,
  AiTriageChatResponse,
  ChatMessage,
  TicketDraft,
  UserProfile,
  UserRole
} from '../types';

let currentAuthToken: string | null = null;
let currentDemoRole: UserRole = 'agent';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

// Request interceptor to attach bearer token and demo role headers
api.interceptors.request.use((config) => {
  if (currentAuthToken) {
    config.headers.Authorization = `Bearer ${currentAuthToken}`;
  } else {
    // Demo header for local development / evaluation mode
    config.headers['X-Demo-Role'] = currentDemoRole;
  }
  return config;
});

export class ApiError extends Error {
  statusCode?: number;
  details?: unknown;
  constructor(message: string, statusCode?: number, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.statusCode = statusCode;
    this.details = details;
  }
}

function handleAxiosError(err: unknown): never {
  if (axios.isAxiosError(err)) {
    const axiosErr = err as AxiosError<{ detail?: string | unknown }>;
    const msg = typeof axiosErr.response?.data?.detail === 'string'
      ? axiosErr.response.data.detail
      : axiosErr.message || 'Network request failed';
    throw new ApiError(msg, axiosErr.response?.status, axiosErr.response?.data);
  }
  throw new ApiError('An unexpected error occurred');
}

export const PriorixApi = {
  setAuthToken(token: string | null) {
    currentAuthToken = token;
  },

  setDemoRole(role: UserRole) {
    currentDemoRole = role;
  },

  getDemoRole(): UserRole {
    return currentDemoRole;
  },

  // Auth & Profile
  async login(payload: { email: string; password: string }): Promise<{ access_token: string; token_type: string; user: UserProfile }> {
    try {
      const res = await api.post('/api/auth/login', payload);
      if (res.data.access_token) {
        this.setAuthToken(res.data.access_token);
      }
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async logout(): Promise<void> {
    try {
      await api.post('/api/auth/logout');
    } catch {
      // Ignore network failure on logout
    } finally {
      this.setAuthToken(null);
    }
  },

  async getMe(): Promise<UserProfile> {
    try {
      const res = await api.get<UserProfile>('/api/me');
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // System Health
  async getHealth() {
    try {
      const res = await api.get('/api/health');
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // Dashboard
  async getDashboardStats(days?: number): Promise<DashboardStats> {
    try {
      const params = days ? { days } : {};
      const res = await api.get<DashboardStats>('/api/dashboard', { params });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // Tickets
  async getTickets(params?: {
    status?: string;
    priority?: string;
    category?: string;
    agent_id?: string;
    incident_id?: string;
    is_overdue?: boolean;
    is_approaching?: boolean;
    search?: string;
    sort_by?: string;
    sort_order?: string;
    page?: number;
    page_size?: number;
  }): Promise<TicketListResponse> {
    try {
      const res = await api.get<TicketListResponse>('/api/tickets', { params });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async getTicket(id: string): Promise<Ticket> {
    try {
      const res = await api.get<Ticket>(`/api/tickets/${id}`);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async createTicket(payload: {
    title?: string;
    subject?: string;
    description: string;
    summary?: string | null;
    category: string;
    customer_name?: string;
    customer_email?: string;
    urgency: string;
    impact: string;
    deadline?: string | null;
    incident_id?: string | null;
    assigned_agent_id?: string | null;
  }): Promise<Ticket> {
    try {
      const res = await api.post<Ticket>('/api/tickets', payload);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async updateTicket(id: string, payload: Partial<Ticket>): Promise<Ticket> {
    try {
      const res = await api.patch<Ticket>(`/api/tickets/${id}`, payload);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async assignTicket(id: string, agentId: string | null, notes?: string): Promise<Ticket> {
    try {
      const res = await api.post<Ticket>(`/api/tickets/${id}/assign`, {
        agent_id: agentId,
        actor: 'Support Supervisor',
        notes
      });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async getTicketHistory(id: string): Promise<TicketHistoryItem[]> {
    try {
      const res = await api.get<TicketHistoryItem[]>(`/api/tickets/${id}/history`);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async getTicketEvents(id: string): Promise<TicketEventItem[]> {
    try {
      const res = await api.get<TicketEventItem[]>(`/api/tickets/${id}/events`);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async getRecommendedAgents(ticketId: string): Promise<AgentRecommendation[]> {
    try {
      const res = await api.get<AgentRecommendation[]>(`/api/tickets/${ticketId}/recommend-agents`);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // Incidents
  async getIncidents(params?: {
    status?: string;
    severity?: string;
    category?: string;
  }): Promise<Incident[]> {
    try {
      const res = await api.get<Incident[]>('/api/incidents', { params });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async getIncident(id: string): Promise<Incident> {
    try {
      const res = await api.get<Incident>(`/api/incidents/${id}`);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async createIncident(payload: {
    title: string;
    description: string;
    category: string;
    severity: string;
    status: string;
    is_verified_critical: boolean;
  }): Promise<Incident> {
    try {
      const res = await api.post<Incident>('/api/incidents', payload);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async updateIncident(id: string, payload: Partial<Incident>): Promise<Incident> {
    try {
      const res = await api.patch<Incident>(`/api/incidents/${id}`, payload);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async linkTicketToIncident(incidentId: string, ticketId: string): Promise<Incident> {
    try {
      const res = await api.post<Incident>(`/api/incidents/${incidentId}/link-ticket`, {
        ticket_id: ticketId
      });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async unlinkTicketFromIncident(incidentId: string, ticketId: string): Promise<Incident> {
    try {
      const res = await api.post<Incident>(`/api/incidents/${incidentId}/unlink-ticket`, {
        ticket_id: ticketId
      });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async getIncidentSuggestedTickets(incidentId: string): Promise<AiRelatedMatch[]> {
    try {
      const res = await api.get<AiRelatedMatch[]>(`/api/incidents/${incidentId}/suggested-tickets`);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // Agents
  async getAgents(): Promise<Agent[]> {
    try {
      const res = await api.get<Agent[]>('/api/agents');
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // AI Features
  async aiCategorize(title: string, description: string): Promise<AiCategorizeResult> {
    try {
      const res = await api.post<AiCategorizeResult>('/api/ai/categorize', { title, description });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async aiAnalyze(payload: {
    title?: string;
    subject?: string;
    description: string;
    customer_name?: string;
    customer_email?: string;
  }): Promise<AiAnalyzeResult> {
    try {
      const res = await api.post<AiAnalyzeResult>('/api/tickets/analyze', payload);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async aiTriageChat(payload: {
    messages: ChatMessage[];
    current_draft?: TicketDraft | null;
  }): Promise<AiTriageChatResponse> {
    try {
      const res = await api.post<AiTriageChatResponse>('/api/chat/triage', payload);
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async aiSuggestResponse(ticketId: string, customInstruction?: string): Promise<AiSuggestResponseResult> {
    try {
      const res = await api.post<AiSuggestResponseResult>('/api/ai/suggest-response', {
        ticket_id: ticketId,
        custom_instruction: customInstruction
      });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async aiRelatedTickets(title: string, description: string, category: string, excludeTicketId?: string): Promise<{ matches: AiRelatedMatch[] }> {
    try {
      const res = await api.post<{ matches: AiRelatedMatch[] }>('/api/tickets/related', {
        title,
        description,
        category,
        exclude_ticket_id: excludeTicketId
      });
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // SLA Operations
  async triggerSlaEscalate() {
    try {
      const res = await api.post('/api/sla/escalate');
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  // Demo Controls
  async resetDemoData() {
    try {
      const res = await api.post('/api/demo/reset');
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  },

  async triggerEscalationScan() {
    try {
      const res = await api.post('/api/demo/trigger-escalation-scan');
      return res.data;
    } catch (e) {
      handleAxiosError(e);
    }
  }
};
